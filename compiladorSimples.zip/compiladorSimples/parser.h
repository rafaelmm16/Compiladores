#include <iostream>
using namespace std;

class Parser{
    public:

        Parser();
        string translateToken(string expressao, string token);
};