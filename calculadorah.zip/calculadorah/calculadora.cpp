#include <iostream>
#include <boost/regex.hpp>
#include<vector>
#include<stdlib.h>

using namespace std;


int main(){
    string expressao;
    vector<int> digitos;
    vector<string> operacoes;
    int soma = 0, a, b;

    cin >> expressao;

    //Regex para analisar se uma expressão é válida
    boost::regex expr{"(\\-{0,1}[0-9]+([+|\\-|\\*|/][0-9]+)+)+"};

	if(boost::regex_match(expressao, expr)){//se a expressão for válida
        cout << "expressao valida" << endl;
        
        boost::regex expr{"\\-{0,1}\\d+"};//regex para separar os digitos
        boost::regex opr{"[+|\\-\\|*|/]+"};//regex para separar os operadores
        
        boost::regex_token_iterator<string::iterator> it2{//separando as ocorrencias da regex selecionada?
            expressao.begin(), expressao.end(), expr, 0
        };

        boost::regex_token_iterator<string::iterator> end;//criando um iterador para servir de ponto de parada para a recursão
        while(it2 != end){//percorrendo as ocorrencias e adicionando-as num vetor
            string temp = *it2; 
            digitos.push_back(stoi(temp));
            cout << temp << endl;
            *it2++;
        }

        boost::regex_token_iterator<string::iterator> it{//separando as ocorrencias da regex selecionada?
            expressao.begin(), expressao.end(), opr, 0
        };

        while(it != end){//percorrendo as ocorrencias e adicionando-as num vetor
            string temp = *it; 
            operacoes.push_back(temp);
            cout << temp << endl;
            *it++;
        }
        
        /* cout << "digitos size: " << digitos.size() << endl;
        cout << "operacoes size: " << operacoes.size() << endl;

        for(int i=0;i<operacoes.size();i++){
            cout << "posicao: " << i << "\t operador: "<< operacoes[i] << endl;
        }
        for(int i=0;i<digitos.size();i++){
            cout << "posicao: " << i << "\t digito: "<< digitos[i] << endl;
        } */
    }

    string menos = "-";
    //acho que talvez uma fila seja mais adequada à situação
    if((operacoes[0].compare("-")==0)&&(digitos[0]<0)){//se o primeiro operador for de negativo e o primeiro número for negativo
        cout << "começa com menos" << endl;
        //remove o operador
        operacoes.erase(operacoes.begin());
    }
    
    soma += digitos[0];
    digitos.erase(digitos.begin());
    
    //loop percorrendo os 2 vetores
    vector<string>::iterator ptr = operacoes.begin();
    //percorre o operador, pega os 2 primeiros numeros, opera, apaga os números, vai pro proximo operador
    while(ptr != operacoes.end()){
        if((*ptr).compare("-")==0)
            soma -= digitos[0];
        else if((*ptr).compare("+")==0)
            soma += digitos[0];
        else if((*ptr).compare("*")==0)
            soma *= digitos[0];
        else if((*ptr).compare("/")==0)
            soma /= digitos[0];
        digitos.erase(digitos.begin());
        ptr++;
    }

    cout << "expressão digitada: " << expressao << endl;
    cout << "resultado: " << soma << endl;
    
    //TALVEZ A REGEX QUE CUIDA DE PEGAR O - DEVA PEGAR APENAS SE HOUVER ALGO ANTES??????


    return 0;
}